<!DOCTYPE html>
<html>
    <head>
        <title>Import|Export Excel</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
         
        <link rel="stylesheet" href="<?php echo e(url('/css/css-custom.css')); ?>">  
        <link rel="stylesheet" href="<?php echo e(url('/css/style.css')); ?>">  
    </head>
    <body>
        <br />
        <div class="container">
            <h3 align="center">Import | Export Excel File </h3>
                <br />
            <!-- error message -->    
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger showSweetAlert">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    Upload Validation Error *<br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- success message -->    
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block showSweetAlert">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            
            <!-- form for upload excel file --> 
            <form method="post" enctype="multipart/form-data" action="<?php echo e(route('import')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <table class="table">
                        <tr>
                            <td width="40%" align="right"><label>Select File for Upload</label></td>
                            <td width="30">
                                <input type="file" name="file" id="file" />
                            </td>
                            <td width="30%" align="left">
                                <input type="submit" name="upload" class="btn btn-primary upload-button" value="Upload">
                                <a href="<?php echo e(route('view')); ?>" type="reset" class="btn btn-danger delete-button">Reset</a>
                            </td>
                        </tr>
                        <tr>
                            <td width="40%" align="right"></td>
                            <td width="30"><span class="text-muted"><b>Only :</b> .xls, .xslx, .csv</span></td>
                            <td width="30%" align="left"></td>
                        </tr>
                    </table>
                </div>
            </form>
            <br />

            <!-- view data list -->
            <div class="panel panel-default">
                <div class="panel-heading" style="background-color:rgb(112, 121, 112); color:#ffff">
                    <h3 class="panel-title"> All Data</h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <?php
                            $count = 1;
                        ?>
                        <?php if(count($data) > 0): ?>
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Action
                                        <a href="<?php echo e(route('download')); ?>" type="button" class="btn btn-success download-button ml-4" align="right">Download</a>
                                    </th>

                                </tr>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td align="right">
                                        <a href="<?php echo e(route('delete',$row->id)); ?>" type="button" class="btn btn-danger delete-button">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </table>
                            <?php else: ?>
                                <span class="form-control" align="center"> 
                                    No Data Available
                                </span>
                        <?php endif; ?>
                        <div class="d-flex justify-content-center text-right">

                            <?php echo e($data->links()); ?>

                
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </body>
</html>
<?php /**PATH /var/www/html/bulk-upload/resources/views/file-upload/import_excel.blade.php ENDPATH**/ ?>